

const mainData = fetch('https://api.stripe.com/v1/charges?limit=100')

function reverseStr(str) {
    return str.split("").reverse().join("")
}

console.log(reverseStr('asdqw'));

function arrNumber(arr,num) {
   return  arr.filter(n=> n===num).length
}

const arrayTest = [1,5,3,1,2,3,]
console.log(arrNumber(arrayTest,1));


